﻿
namespace Peso_Ideal
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.labAltura = new System.Windows.Forms.Label();
            this.labPeso = new System.Windows.Forms.Label();
            this.radioM = new System.Windows.Forms.RadioButton();
            this.radioF = new System.Windows.Forms.RadioButton();
            this.butCalcular = new System.Windows.Forms.Button();
            this.groupPIdeal = new System.Windows.Forms.GroupBox();
            this.maskAltura = new System.Windows.Forms.MaskedTextBox();
            this.maskPeso = new System.Windows.Forms.MaskedTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textPIdeal = new System.Windows.Forms.TextBox();
            this.groupPIdeal.SuspendLayout();
            this.SuspendLayout();
            // 
            // labAltura
            // 
            this.labAltura.AutoSize = true;
            this.labAltura.Location = new System.Drawing.Point(28, 55);
            this.labAltura.Name = "labAltura";
            this.labAltura.Size = new System.Drawing.Size(34, 13);
            this.labAltura.TabIndex = 0;
            this.labAltura.Text = "Altura";
            // 
            // labPeso
            // 
            this.labPeso.AutoSize = true;
            this.labPeso.Location = new System.Drawing.Point(28, 90);
            this.labPeso.Name = "labPeso";
            this.labPeso.Size = new System.Drawing.Size(31, 13);
            this.labPeso.TabIndex = 1;
            this.labPeso.Text = "Peso";
            // 
            // radioM
            // 
            this.radioM.AutoSize = true;
            this.radioM.Checked = true;
            this.radioM.Location = new System.Drawing.Point(21, 19);
            this.radioM.Name = "radioM";
            this.radioM.Size = new System.Drawing.Size(34, 17);
            this.radioM.TabIndex = 5;
            this.radioM.TabStop = true;
            this.radioM.Text = "M";
            this.radioM.UseVisualStyleBackColor = true;
            // 
            // radioF
            // 
            this.radioF.AutoSize = true;
            this.radioF.Location = new System.Drawing.Point(66, 19);
            this.radioF.Name = "radioF";
            this.radioF.Size = new System.Drawing.Size(31, 17);
            this.radioF.TabIndex = 6;
            this.radioF.Text = "F";
            this.radioF.UseVisualStyleBackColor = true;
            // 
            // butCalcular
            // 
            this.butCalcular.Location = new System.Drawing.Point(81, 246);
            this.butCalcular.Name = "butCalcular";
            this.butCalcular.Size = new System.Drawing.Size(89, 34);
            this.butCalcular.TabIndex = 7;
            this.butCalcular.Text = "Calcular";
            this.butCalcular.UseVisualStyleBackColor = true;
            this.butCalcular.Click += new System.EventHandler(this.butCalcular_Click);
            // 
            // groupPIdeal
            // 
            this.groupPIdeal.Controls.Add(this.radioM);
            this.groupPIdeal.Controls.Add(this.radioF);
            this.groupPIdeal.Location = new System.Drawing.Point(69, 127);
            this.groupPIdeal.Name = "groupPIdeal";
            this.groupPIdeal.Size = new System.Drawing.Size(112, 51);
            this.groupPIdeal.TabIndex = 8;
            this.groupPIdeal.TabStop = false;
            this.groupPIdeal.Text = "Sexo";
            this.groupPIdeal.Enter += new System.EventHandler(this.groupPIdeal_Enter);
            // 
            // maskAltura
            // 
            this.maskAltura.Location = new System.Drawing.Point(81, 52);
            this.maskAltura.Mask = "0.00";
            this.maskAltura.Name = "maskAltura";
            this.maskAltura.Size = new System.Drawing.Size(100, 20);
            this.maskAltura.TabIndex = 9;
            this.maskAltura.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.maskAltura_MaskInputRejected);
            // 
            // maskPeso
            // 
            this.maskPeso.Location = new System.Drawing.Point(81, 87);
            this.maskPeso.Mask = "000.000";
            this.maskPeso.Name = "maskPeso";
            this.maskPeso.Size = new System.Drawing.Size(100, 20);
            this.maskPeso.TabIndex = 10;
            this.maskPeso.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.maskPeso_MaskInputRejected);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 209);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 13);
            this.label1.TabIndex = 11;
            this.label1.Text = "Peso Ideal";
            // 
            // textPIdeal
            // 
            this.textPIdeal.Location = new System.Drawing.Point(81, 206);
            this.textPIdeal.Name = "textPIdeal";
            this.textPIdeal.Size = new System.Drawing.Size(100, 20);
            this.textPIdeal.TabIndex = 12;
            this.textPIdeal.TextChanged += new System.EventHandler(this.textPIdeal_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(253, 307);
            this.Controls.Add(this.textPIdeal);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.maskPeso);
            this.Controls.Add(this.maskAltura);
            this.Controls.Add(this.groupPIdeal);
            this.Controls.Add(this.butCalcular);
            this.Controls.Add(this.labPeso);
            this.Controls.Add(this.labAltura);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Name = "Form1";
            this.Text = "Peso Ideal";
            this.groupPIdeal.ResumeLayout(false);
            this.groupPIdeal.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labAltura;
        private System.Windows.Forms.Label labPeso;
        private System.Windows.Forms.RadioButton radioM;
        private System.Windows.Forms.RadioButton radioF;
        private System.Windows.Forms.Button butCalcular;
        private System.Windows.Forms.GroupBox groupPIdeal;
        private System.Windows.Forms.MaskedTextBox maskAltura;
        private System.Windows.Forms.MaskedTextBox maskPeso;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textPIdeal;
    }
}

