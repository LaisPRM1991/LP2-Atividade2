﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Peso_Ideal
{
    public partial class Form1 : Form
    {
        double peso, altura, peso_ideal;
        public Form1()
        {
            InitializeComponent();
           
        }

     
        private void maskAltura_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void maskPeso_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void textPIdeal_TextChanged(object sender, EventArgs e)
        {

        }

        private void butCalcular_Click(object sender, EventArgs e)
        {
            if (double.TryParse(maskAltura.Text, out altura) && 
                double.TryParse(maskPeso.Text, out peso))
            {
                if (radioM.Checked == true || radioF.Checked == true)

                {
                    if (radioM.Checked == true)
                    {
                        peso_ideal = (72.7 * altura) - 58;
                    }

                    else
                    {
                        peso_ideal = (62.1 * altura) - 44.7;
                    }

                    textPIdeal.Text = peso_ideal.ToString();

                    if (peso > peso_ideal)
                    {                        
                        MessageBox.Show("Regime obrigatorio ja!");
                    }

                    else if (peso == peso_ideal)
                    {
                        MessageBox.Show("Voce esta com o peso ideal!");
                    }

                    else if (peso < peso_ideal)
                    {
                        MessageBox.Show("Coma bastante massas e doces!");
                    }
                }

                else
                    MessageBox.Show("Sexo não selecionado");
            }
            else
                MessageBox.Show("Dados Inválidos!");
        }

            
        private void groupPIdeal_Enter(object sender, EventArgs e)
        {
            
        }
    }
}
